<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DemandeExplication extends Model
{
    use HasFactory;
    // protected $fillable = [];
    protected $fillable = [
        'initiateur',
        'destinataire',
        'entity_id',
        'motif_id',
        'description',
        'reponse',
        'sent_file_path',
        'answered_file_path',
        'numero_demande_explication',
        'date_incident',
        'date_decharge',
        'date_reponse',
    ];

    public function motif()
    {
        return $this->belongsTo(Motif::class);
    }

    public function destinataires(){
        return $this->belongsTo(User::class, 'destinataire');
    }

    public function emetteur(){
        return $this->belongsTo(User::class, 'initiateur');
    }

    public function piece_jointes(){
        return $this->hasMany(PieceJointe::class);
    }
    
    public function piece_jointes_reponse(){
        return $this->hasMany(PieceJointeReponse::class);
    }

    public function notifications(){
        return $this->hasMany(Notification::class);
    }

    public function sanction(){
        return $this->hasOne(Sanction::class);
    }
}
