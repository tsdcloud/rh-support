<?php

namespace App\Http\Controllers;

use App\Mail\DecisionSanctionMail;
use App\Mail\PropositionSanctionMail;
use App\Models\DemandeExplication;
use App\Models\Notification;
use App\Models\PropositionSanction;
use App\Models\Sanction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class SanctionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function history(){

        $users = User::whereHas('sanctions')->get();

        return view('sanctions.history', compact('users'));
    }

    // public function show(User $user){
    //     // dd($user);

    //     return view('sanctions.show');
    // }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    public function proposition(Request $request, User $user){
        // dump($user);

        $data = $request->validate([
            'proposition_sanction' => 'required',
            'demande_explication_id' => 'required',
            'user_id' => 'required',
        ],[
            'proposition_sanction.required' => 'La description de proposition de sanction est requise',
            'demande_explication_id.required' => 'Une erreur s\est produite. Veuillez reprendre',
            'user_id.required' => 'Une erreur s\est produite. Veuillez reprendre',
        ]);

        // dd($request->all());
        $data['user_id'] = $user->id;

        $proposition_sanction = PropositionSanction::create($data);

        $demande_explication = DemandeExplication::find($request->demande_explication_id);

        $mailData = [
            'emetteur_fname' => $demande_explication->emetteur->fname,
            'emetteur_lname' => $demande_explication->emetteur->lname,
            'motif' => $demande_explication->motif->motif,
            'destinataire_fname' => $demande_explication->destinataires->fname,
            'destinataire_lname' => $demande_explication->destinataires->lname,
            'proposition_fname' => auth()->user()->fname,
            'proposition_lname' =>  auth()->user()->lname,    
            'proposition_sanction' => $proposition_sanction->proposition->motif,    
            'demande_explication_id' => $demande_explication->id,
        ];

        if($request->user_id != 0){
            $user = User::find($request->user_id);
            try{
                Notification::create([
                    'demande_explication_id' => $demande_explication->id,
                    'user_id' => $user->id,
                    'motif' => 'proposition_sanction',
                ]);
                $objet = 'Proposition de sanction';
                $this->sendMailFunction($user->email, $mailData, $objet);
            }catch(\Exception $e){
                alert()->error('Attention', 'Echec de notification par mail');
            }
        }else{
            
            $user = User::whereHas('decision_sanction')->first();
            
            try{
                Notification::create([
                    'demande_explication_id' => $demande_explication->id,
                    'user_id' => $user->id,
                    'motif' => 'invitation_decision_sanction',
                ]);
                $objet = 'Invitation - Décision de sanction';
                $this->sendMailFunction($user->email, $mailData, $objet);
                
            }catch(\Exception $e){
                alert()->error('Attention', 'Echec de notification par mail');
            }
        }

        alert()->success('Opération réussie', 'Proposition de sanction effectuée avec succès');

        return back()->with('success', 'Proposition de sanction effectuée avec succès');
    }

    public function sendMailFunction($email, $mailData, $objet){
        Mail::to($email)->send(new PropositionSanctionMail($mailData, $objet));
    }

    public function decision(Request $request, User $user){
        // dump($request->all());
        // dd($user);

        $data = $request->validate([
            "demande_explication_id" => "required",
            "decision" => "required",
        ]);

        // try{
            DB::beginTransaction();
            
            $demande = DemandeExplication::find($data['demande_explication_id']);
            $demande->status = true;
            $demande->save();
            
            $data['user_id'] = $demande->destinataire;
            $data['decideur'] = $user->id;
            
            if(Sanction::where($data)->exists()){
                return back()->with('warning', 'Décision de sanction déjà effectuée');
            }
            $decision_sanction = Sanction::create($data);

            
            $notifications = Notification::where('demande_explication_id', $demande->id)->get();
            DB::commit();
            // dd($decision_sanction->decisions->motif);

            $mailData = [
                'emetteur_fname' => $demande->emetteur->fname,
                'emetteur_lname' => $demande->emetteur->lname,
                'motif' => $demande->motif->motif,
                'destinataire_fname' => $demande->destinataires->fname,
                'destinataire_lname' => $demande->destinataires->lname,
                'decision' => $decision_sanction->decisions->motif,
                'demande_explication_id' => $demande->id,
            ];

            foreach($notifications as $notification){
                Mail::to($notification->user->email)->send(new DecisionSanctionMail($mailData));
            }

        // }catch(\Exception $e){
        //     DB::rollBack();
        // }

        return back()->with('success', 'Décision de sanction effectuée avec succès');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(User $user){

        // $demande = DemandeExplication::where('destinataire', $user->id)->orderBy('id', 'DESC')->get();
        return view('sanctions.show', compact('user'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
