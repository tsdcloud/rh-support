<?php

namespace App\Http\Controllers;

use App\Mail\DemandeExplicationSendMail;
use App\Models\DemandeExplication;
use App\Models\Fonction;
use App\Models\Motif;
use App\Models\MotifSanction;
use App\Models\Notification;
use App\Models\PieceJointe;
use App\Models\PieceJointeReponse;
use App\Models\User;
use DateTime;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Str;

class DeOperation extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(){
        $current_user_id = auth()->user()->grade_id;
        // $grade_id = ;
        // $entity_id = ;

        $fonction = Fonction::find(session('fonction_id')['fonction_id']);

        // A revoir car, on ne peut pas se donner soi-meme des DE
        $destinataires = User::whereRelation('user_entity', 'grade_id', '<', $fonction->user_entity->grade_id)
                            ->whereRelation('user_entity', 'entity_id', '=', $fonction->user_entity->entity_id)
                            ->where('id', '!=', auth()->user()->id)->get();
        $users_encopies = User::whereRelation('user_entity', 'grade_id', '>=', $fonction->user_entity->grade_id)->where('id', '!=', auth()->user()->id)->get();

        $motifs = Motif::orderBy('motif', 'ASC')->get();

        return view('demandes_explication.create', compact('users_encopies','destinataires', 'motifs'));
    }

    public function de_enattente(){

        // $grade_current = auth()->user()->user_entity->grade_id;

        // dd($grade_current);
        $demandes = DemandeExplication::where('status', false)->orderBy('id', 'DESC')->get();
        return view('demandes_explication.enattente', compact('demandes'));
    }

    public function de_repondre(){
        $user_id = auth()->user()->id;
        $demandes = DemandeExplication::where(['status'=> false, 'destinataire'=>$user_id])->orderBy('id', 'DESC')->get();
        return view('demandes_explication.repondre', compact('demandes'));
    }

    public function de_archived(){
        $demandes = DemandeExplication::where('status', true)->get();
        return view('demandes_explication.archived', compact('demandes'));
    }

    public function de_answered(Request $request, $demande){
        $data = $request->validate([
            'reponse'=>'required|string',
        ],[
            'reponse.required' => "Le champ de reponse est requis",
            'reponse.string' => "Le champ de reponse doit etre un texte",
        ]);

        try{
            $reponse_demande = DemandeExplication::find($demande);

            if($reponse_demande->destinataire != auth()->user()->id){
                alert()->error('Attention', 'Une erreur s\'est produite');
                return back()->with('error', 'Une erreur s\'est produite');
            }

            if($reponse_demande->reponse){
                alert()->error('Attention', 'Vous avez déjà répondu à cette demande d\'explication');
                return back()->with('error', 'Vous avez déjà répondu à cette demande d\'explication');
            }else{
                $reponse_demande->reponse = $request->reponse;
                $reponse_demande->date_reponse = date('Y-m-d H:i:s');

                $reponse_demande->save();

                // dd($request->pieces_jointe);
                if($request->has('pieces_jointe')){

                    $request->validate([
                        'pieces_jointe.*' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                    ],[
                        'pieces_jointe.required' => 'le choix d\'image est requis',
                        'pieces_jointe.image' => 'le fichier choisi doit etre de type image',
                        'pieces_jointe.max' => 'la taille maximale du fichier choisi est 2048 octects',
                        'pieces_jointe.mimes' => 'le fichier choisi doit etre de type image(jpeg, png, jpg, gif, svg)',
                    ]);

                    foreach($request->pieces_jointe as $pieces_jointe){
                        $fileName = time().'.'.$pieces_jointe->extension();
                        $pieces_jointe->move(public_path('images'), $fileName);

                        $pieces_jointe = PieceJointeReponse::create([
                            'piece_jointe' => $fileName,
                            'demande_explication_id' => $reponse_demande->id,
                        ]);
                    }
                }
                alert()->success('Succès', 'Demande répondue avec success');

                return back()->with('success', 'Demande répondue avec success');
            }
        }catch(\Exception $e){
            alert()->error('Attention', 'Une erreur s\'est produite');
            return back()->with('error', 'Une erreur s\'est produite');
        }

    }

    public function numero_demande_explication($demande_explication_id){
        $date = Str::Substr(date('Y'), -2);

        $length = Str::length($demande_explication_id);
        $zeros = '';

        for($k = 1; $k <= (6 - $length); $k++){
            $zeros .= '0';
        }
        return $zeros . $demande_explication_id . '/' . $date;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){
        $data = $request->validate([
            'destinataire'=>'required|integer',
            'motif_id'=>'required|integer',
            'description'=>'required|string',
        ],[
            'destinataire.required' => "Veuillez choisir un destinataire",
            'destinataire.integer' => "Veuillez choisir un destinataire",
            'motif_id.required' => "Veuillez choisir un motif",
            'motif_id.integer' => "Veuillez choisir un motif",
            'description.required' => "Veuillez remplir la description",
            'description.string' => "La description doit etre un texte",
        ]);

        $data['entity_id'] = Fonction::find(session('fonction_id')['fonction_id'])->user_entity->entity_id;

        if($request->entity_id){
            $data['entity_id'] = $request->entity_id;
        }

        $data['initiateur'] = auth()->user()->id;

        // dd($data);
        DB::beginTransaction();
        $demande_explication = DemandeExplication::create($data);

        $demande_explication->update([
            'numero_demande_explication' => $this->numero_demande_explication($demande_explication->id),
        ]);

        // $numero

        if($request->has('pieces_jointe')){
            $request->validate([
                'pieces_jointe.*' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ],[
                'pieces_jointe.required' => 'le choix d\'image est requis',
                'pieces_jointe.image' => 'le fichier choisi doit etre de type image',
                'pieces_jointe.max' => 'la taille maximale du fichier choisi est 2048 octects',
                'pieces_jointe.mimes' => 'le fichier choisi doit etre de type image(jpeg, png, jpg, gif, svg)',
            ]);

            foreach($request->pieces_jointe as $pieces_jointe){
                $fileName = time().'.'.$pieces_jointe->extension();
              //  $pieces_jointe->move(public_path('images'), $fileName);

                $pieces_jointe = PieceJointe::create([
                    'piece_jointe' => $pieces_jointe->store('images','public'),
                    'demande_explication_id' => $demande_explication->id,
                ]);
            }
        }

        Notification::create([
            'demande_explication_id' => $demande_explication->id,
            'user_id' => $data['initiateur'],
            'motif' => 'demande_explication',
        ]);

        Notification::create([
            'demande_explication_id' => $demande_explication->id,
            'user_id' => $demande_explication->destinataire,
            'motif' => 'demande_explication',
        ]);

        if($personnes = $request->personnes_en_copie){
            foreach($personnes as $key => $personne)

            Notification::create([
                'demande_explication_id'=>$demande_explication->id,
                'user_id'=>$personne,
                'motif' => 'demande_explication',
            ]);
        }

        $fonction = Fonction::find(session('fonction_id')['fonction_id']);
        $mailData = [
            'emetteur_fname' => auth()->user()->fname,
            'emetteur_lname' => auth()->user()->lname,
            'emetteur_fonction' => $fonction->fonction,
            'emetteur_grade' => $fonction->user_entity->grade->title,
            'motif' => $demande_explication->motif->motif,
            'destinataire_fname' => $demande_explication->destinataires->fname,
            'destinataire_lname' => $demande_explication->destinataires->lname,
            'description' => $demande_explication->description,
            'demande_explication_id' => $demande_explication->id,
        ];


        // Notifications de ceux qui sont en copie et initiateur et destinataire
        $notifications = Notification::where([
            'demande_explication_id' => $demande_explication->id
        ])->get();

        foreach($notifications as $notification){
            $this->sendMailFunction($notification->user->email, $mailData);
        }

        DB::commit();

        alert()->success('Succès', 'Demande d\'explication envoyée avec succès');
        return redirect()->route('de.enattente')->with('succes', 'Demande d\'explication envoyée avec succès');
    }

    public function sendMailFunction($email, $mailData){
        Mail::to($email)->send(new DemandeExplicationSendMail($mailData));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(DemandeExplication $demande){
        $check_abilities_showing_de = $demande->whereRelation('notifications', function (Builder $query) {
            $query->where('user_id', auth()->user()->id);
        })->exists();


        if($check_abilities_showing_de){

            $fonction = Fonction::find(session('fonction_id')['fonction_id']);

            $hierarchic_superiors = User::whereHas('user_entity', function($query) use($fonction){
                $query->where('grade_id', '>=', $fonction->user_entity->grade_id);
            })->where('id', '!=', auth()->user()->id)->get();

            $motif_sanctions = MotifSanction::get();
            return view('demandes_explication.show', compact('demande', 'motif_sanctions', 'hierarchic_superiors'));
        }else{
            return back();
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
