<?php

use App\Models\Fonction;
use App\Models\Inscription;
use App\Models\PropositionSanction;
use App\Models\Sanction;
use App\Models\User;
use Illuminate\Support\Str;
use Carbon\Carbon;

function setMenuActive($route){
    $routeActuel = request()->route()->getName();

    if($routeActuel === $route){
        return 'active';
    }
    if(isContained($routeActuel, $route)){
        return 'active';
    }
    return "";
}

function stringToLowercase($value){
    return Str::of($value)->lower();
}

function isContained($container, $content){
    return Str::contains($container, $content);
}

function listOfPrivileges($lists){
    $list = "";
    $number_of_privilege = count($lists);

    foreach ($lists as $selfprivilege){
        $list = $list . $selfprivilege->name_of_privilege;

        if($number_of_privilege > 1){
            $list = $list . "; ";
        }

        $number_of_privilege --;
    }
    return $list;
}

function setDate($dateInput){
    if($dateInput){
        $date = Carbon::parse($dateInput, 'UTC');    
        return $date->isoFormat('MMMM Do YYYY, h:mm:ss a');
    }
}

function changeDateFormat($date){

    // $date = Carbon::createFromIsoFormat('!YYYY-MMMM-D h:mm:ss a', '2019-January-3 6:33:24 pm', 'UTC');
    // echo $date->isoFormat('M/D/YY HH:mm');

    $date = Carbon::parse($date, 'UTC');

    return $date->isoFormat('d/m/Y à HH:mm');
}

function getEntity($fonction_id){

    if(!session()->has('fonction_id')){
        return route('login');
    }
    
    $fonction = Fonction::find($fonction_id['fonction_id']);
    return $fonction->fonction;
}

function getEntityImg($fonction_id){
    if(!session()->has('fonction_id')){
        return route('login');
    }
    $fonction = Fonction::find($fonction_id['fonction_id']);

    return $fonction->user_entity->entity->logo;
}

function getFunctions($fonction_id){
    $fonction = Fonction::find($fonction_id['fonction_id']);

    return Fonction::where(['user_entity_id' => $fonction->user_entity_id])->get();
}

function checkPropositionSanction($user_id, $demande_explication_id){
    return PropositionSanction::where([
        'user_id' => $user_id,
        'demande_explication_id' => $demande_explication_id
    ])->first();
}

function checkDecisionSanction($demande_explication_id){
    return Sanction::where('demande_explication_id',$demande_explication_id)->first();
}

function getDecideurSanctionDE(){
    return User::has('decision_sanction')->get();
}