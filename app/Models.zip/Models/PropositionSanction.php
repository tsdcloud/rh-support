<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PropositionSanction extends Model
{
    use HasFactory;
    protected $fillable = [
        'proposition_sanction',
        'user_id',
        'sanction_id',
    ];
}
